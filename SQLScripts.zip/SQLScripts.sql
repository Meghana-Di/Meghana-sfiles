USE [Work2021]
GO
/****** Object:  User [access]    Script Date: 3/15/2021 11:49:20 PM ******/
CREATE USER [access] FOR LOGIN [access] WITH DEFAULT_SCHEMA=[dbo]
GO
/****** Object:  Table [dbo].[InvoiceDetails]    Script Date: 3/15/2021 11:49:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[InvoiceDetails](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[InvoiceNumber] [nvarchar](50) NULL,
	[InvoiceAmount] [money] NULL,
	[PurchaseOrderNumber] [nvarchar](40) NULL,
	[InvoiceType] [nvarchar](10) NULL,
	[Company] [nvarchar](100) NULL,
	[Country] [nvarchar](100) NULL,
 CONSTRAINT [PK_InvoiceDetails] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[InvoiceDetailsDump]    Script Date: 3/15/2021 11:49:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[InvoiceDetailsDump](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[InvoiceNumber] [nvarchar](50) NULL,
	[InvoiceAmount] [money] NULL,
	[PurchaseOrderNumber] [nvarchar](40) NULL,
	[InvoiceType] [nvarchar](10) NULL,
	[Company] [nvarchar](100) NULL,
	[Country] [nvarchar](100) NULL,
 CONSTRAINT [PK_InvoiceDetailsDump] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TblEmployee]    Script Date: 3/15/2021 11:49:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TblEmployee](
	[EmployeeID] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](50) NULL,
	[Gender] [nvarchar](50) NULL,
	[Country] [nvarchar](50) NULL,
	[Salary] [money] NULL,
	[Email] [nvarchar](100) NULL,
 CONSTRAINT [PK_TblEmployee] PRIMARY KEY CLUSTERED 
(
	[EmployeeID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Users]    Script Date: 3/15/2021 11:49:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Users](
	[UserId] [int] NULL,
	[Username] [nvarchar](max) NULL,
	[Password] [nvarchar](max) NULL,
	[Email] [nvarchar](max) NULL,
	[Creationdate] [datetime] NULL,
	[LastLoginDate] [datetime] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
SET IDENTITY_INSERT [dbo].[InvoiceDetails] ON 
GO
INSERT [dbo].[InvoiceDetails] ([ID], [InvoiceNumber], [InvoiceAmount], [PurchaseOrderNumber], [InvoiceType], [Company], [Country]) VALUES (1, N'12345', 100.0000, N'12345', N'RTq', N'OBS', N'London')
GO
INSERT [dbo].[InvoiceDetails] ([ID], [InvoiceNumber], [InvoiceAmount], [PurchaseOrderNumber], [InvoiceType], [Company], [Country]) VALUES (4, N'100001', 100.0000, N'12345', N'KT', N'SLB', N'London')
GO
INSERT [dbo].[InvoiceDetails] ([ID], [InvoiceNumber], [InvoiceAmount], [PurchaseOrderNumber], [InvoiceType], [Company], [Country]) VALUES (5, N'100002', 200.0000, N'12346', N'KR', N'SLB', N'London')
GO
INSERT [dbo].[InvoiceDetails] ([ID], [InvoiceNumber], [InvoiceAmount], [PurchaseOrderNumber], [InvoiceType], [Company], [Country]) VALUES (6, N'100003', 300.0000, N'12347', N'RT', N'SLB', N'London')
GO
INSERT [dbo].[InvoiceDetails] ([ID], [InvoiceNumber], [InvoiceAmount], [PurchaseOrderNumber], [InvoiceType], [Company], [Country]) VALUES (7, N'100004', 400.0000, N'12348', N'ZT', N'SLB', N'London')
GO
INSERT [dbo].[InvoiceDetails] ([ID], [InvoiceNumber], [InvoiceAmount], [PurchaseOrderNumber], [InvoiceType], [Company], [Country]) VALUES (8, N'100005', 500.0000, N'12349', N'QT', N'SLB', N'London')
GO
INSERT [dbo].[InvoiceDetails] ([ID], [InvoiceNumber], [InvoiceAmount], [PurchaseOrderNumber], [InvoiceType], [Company], [Country]) VALUES (9, N'100006', 600.0000, N'12350', N'KT', N'SLB', N'London')
GO
INSERT [dbo].[InvoiceDetails] ([ID], [InvoiceNumber], [InvoiceAmount], [PurchaseOrderNumber], [InvoiceType], [Company], [Country]) VALUES (10, N'100007', 700.0000, N'12351', N'KR', N'SLB', N'London')
GO
INSERT [dbo].[InvoiceDetails] ([ID], [InvoiceNumber], [InvoiceAmount], [PurchaseOrderNumber], [InvoiceType], [Company], [Country]) VALUES (63, N'56', 122.0000, N'1234', N'KT', N'SAU', N'Canada')
GO
SET IDENTITY_INSERT [dbo].[InvoiceDetails] OFF
GO
SET IDENTITY_INSERT [dbo].[TblEmployee] ON 
GO
INSERT [dbo].[TblEmployee] ([EmployeeID], [Name], [Gender], [Country], [Salary], [Email]) VALUES (1, N'Russ', N'F', N'London', 340303.0000, NULL)
GO
INSERT [dbo].[TblEmployee] ([EmployeeID], [Name], [Gender], [Country], [Salary], [Email]) VALUES (6, N'Amit Dumbani', N'M', N'India', 38493.0000, N'1Amit Dumbani@gmail.com')
GO
INSERT [dbo].[TblEmployee] ([EmployeeID], [Name], [Gender], [Country], [Salary], [Email]) VALUES (7, N'AshutoshSarpotdar', N'M', N'France', 482902.0000, N'1AshutoshSarpotdar@gmail.com')
GO
INSERT [dbo].[TblEmployee] ([EmployeeID], [Name], [Gender], [Country], [Salary], [Email]) VALUES (8, N'AsmitaSalvi', N'F', N'China', 2222.0000, N'1AsmitaSalvi@gmail.com')
GO
INSERT [dbo].[TblEmployee] ([EmployeeID], [Name], [Gender], [Country], [Salary], [Email]) VALUES (9, N'DarshanPolji', N'M', N'London', 2442.0000, N'1DarshanPolji@gmail.com')
GO
INSERT [dbo].[TblEmployee] ([EmployeeID], [Name], [Gender], [Country], [Salary], [Email]) VALUES (10, N'DeepakDighe', N'M', N'France', 24555.0000, N'1DeepakDighe@gmail.com')
GO
INSERT [dbo].[TblEmployee] ([EmployeeID], [Name], [Gender], [Country], [Salary], [Email]) VALUES (11, N'FazalahmedShaikh', N'M', N'China', 543.0000, N'1FazalahmedShaikh@gmail.com')
GO
INSERT [dbo].[TblEmployee] ([EmployeeID], [Name], [Gender], [Country], [Salary], [Email]) VALUES (12, N'GajendraVankar', N'M', N'Korea', 21131.0000, N'1GajendraVankar@gmail.com')
GO
INSERT [dbo].[TblEmployee] ([EmployeeID], [Name], [Gender], [Country], [Salary], [Email]) VALUES (13, N'GanpatSawant', N'M', N'Korea', 12455.0000, N'1GanpatSawant@gmail.com')
GO
INSERT [dbo].[TblEmployee] ([EmployeeID], [Name], [Gender], [Country], [Salary], [Email]) VALUES (14, N'JiwikaBachhav', N'F', N'India', 12321.0000, N'1JiwikaBachhav@gmail.com')
GO
INSERT [dbo].[TblEmployee] ([EmployeeID], [Name], [Gender], [Country], [Salary], [Email]) VALUES (15, N'KinjalJaiswar', N'F', N'France', 13455.0000, N'1KinjalJaiswar@gmail.com')
GO
INSERT [dbo].[TblEmployee] ([EmployeeID], [Name], [Gender], [Country], [Salary], [Email]) VALUES (16, N'MelvinePinto', N'F', N'INdia', 11244.0000, N'1MelvinePinto@gmail.com')
GO
INSERT [dbo].[TblEmployee] ([EmployeeID], [Name], [Gender], [Country], [Salary], [Email]) VALUES (17, N'NayanaSawant', N'F', N'London', 1234.0000, N'1NayanaSawant@gmail.com')
GO
INSERT [dbo].[TblEmployee] ([EmployeeID], [Name], [Gender], [Country], [Salary], [Email]) VALUES (18, N'NevilleMotafram', N'F', N'France', 11345.0000, N'1NevilleMotafram@gmail.com')
GO
INSERT [dbo].[TblEmployee] ([EmployeeID], [Name], [Gender], [Country], [Salary], [Email]) VALUES (19, N'NileshRathod', N'M', N'China', 8866.0000, N'1NileshRathod@gmail.com')
GO
INSERT [dbo].[TblEmployee] ([EmployeeID], [Name], [Gender], [Country], [Salary], [Email]) VALUES (20, N'NitinJaywant Shinde', N'M', N'India', 7755.0000, N'1NitinJaywant Shinde@gmail.com')
GO
INSERT [dbo].[TblEmployee] ([EmployeeID], [Name], [Gender], [Country], [Salary], [Email]) VALUES (21, N'PiyushMehta', N'M', N'Korea', 76544.0000, N'1PiyushMehta@gmail.com')
GO
INSERT [dbo].[TblEmployee] ([EmployeeID], [Name], [Gender], [Country], [Salary], [Email]) VALUES (22, N'PrasannaNagaraju', N'M', N'Korea', 32568.0000, N'1PrasannaNagaraju@gmail.com')
GO
INSERT [dbo].[TblEmployee] ([EmployeeID], [Name], [Gender], [Country], [Salary], [Email]) VALUES (23, N'PriyaPatel', N'F', N'London', 6654.0000, N'1PriyaPatel@gmail.com')
GO
INSERT [dbo].[TblEmployee] ([EmployeeID], [Name], [Gender], [Country], [Salary], [Email]) VALUES (24, N'RanjithaGaniga', N'F', N'China', 444.0000, N'1RanjithaGaniga@gmail.com')
GO
INSERT [dbo].[TblEmployee] ([EmployeeID], [Name], [Gender], [Country], [Salary], [Email]) VALUES (25, N'SarikaMirge', N'F', N'China', 4332.0000, N'1SarikaMirge@gmail.com')
GO
INSERT [dbo].[TblEmployee] ([EmployeeID], [Name], [Gender], [Country], [Salary], [Email]) VALUES (26, N'sayaliKadam', N'F', N'France', 23.0000, N'1sayaliKadam@gmail.com')
GO
INSERT [dbo].[TblEmployee] ([EmployeeID], [Name], [Gender], [Country], [Salary], [Email]) VALUES (27, N'ShwetaControllu', N'F', N'France', 22.0000, N'1ShwetaControllu@gmail.com')
GO
INSERT [dbo].[TblEmployee] ([EmployeeID], [Name], [Gender], [Country], [Salary], [Email]) VALUES (28, N'SomnathSarkar', N'F', N'London', 22.0000, N'1SomnathSarkar@gmail.com')
GO
INSERT [dbo].[TblEmployee] ([EmployeeID], [Name], [Gender], [Country], [Salary], [Email]) VALUES (29, N'SurajChachlani', N'F', N'London', 44.0000, N'1SurajChachlani@gmail.com')
GO
INSERT [dbo].[TblEmployee] ([EmployeeID], [Name], [Gender], [Country], [Salary], [Email]) VALUES (30, N'SushmaNilange', N'F', N'London', 667.0000, N'1SushmaNilange@gmail.com')
GO
INSERT [dbo].[TblEmployee] ([EmployeeID], [Name], [Gender], [Country], [Salary], [Email]) VALUES (31, N'SapnilWaghdhare', N'F', N'London', 6544.0000, N'1SapnilWaghdhare@gmail.com')
GO
INSERT [dbo].[TblEmployee] ([EmployeeID], [Name], [Gender], [Country], [Salary], [Email]) VALUES (32, N'VinayakDabade', N'M', N'India', 4466.0000, N'1VinayakDabade@gmail.com')
GO
INSERT [dbo].[TblEmployee] ([EmployeeID], [Name], [Gender], [Country], [Salary], [Email]) VALUES (33, N'VinitDhamale', N'M', N'India', 4466.0000, N'1VinitDhamale@gmail.com')
GO
INSERT [dbo].[TblEmployee] ([EmployeeID], [Name], [Gender], [Country], [Salary], [Email]) VALUES (34, N'vishalChakre', N'M', N'China', 4456.0000, N'1vishalChakre@gmail.com')
GO
INSERT [dbo].[TblEmployee] ([EmployeeID], [Name], [Gender], [Country], [Salary], [Email]) VALUES (35, N'ankitachaturvedi', N'F', N'France', 445.0000, N'1ankitachaturvedi@gmail.com')
GO
INSERT [dbo].[TblEmployee] ([EmployeeID], [Name], [Gender], [Country], [Salary], [Email]) VALUES (36, N'AnkitaMehra', N'F', N'France', 888.0000, N'1AnkitaMehra@gmail.com')
GO
INSERT [dbo].[TblEmployee] ([EmployeeID], [Name], [Gender], [Country], [Salary], [Email]) VALUES (37, N'VishwanathaG S', N'M', N'China', 100.0000, N'1VishwanathaG S@gmail.com')
GO
INSERT [dbo].[TblEmployee] ([EmployeeID], [Name], [Gender], [Country], [Salary], [Email]) VALUES (38, N'ShreyaShreya', N'F', N'Korea', 88765.0000, N'1ShreyaShreya@gmail.com')
GO
INSERT [dbo].[TblEmployee] ([EmployeeID], [Name], [Gender], [Country], [Salary], [Email]) VALUES (39, N'AnkitaGupta', N'F', N'Korea', 400.0000, N'1AnkitaGupta@gmail.com')
GO
INSERT [dbo].[TblEmployee] ([EmployeeID], [Name], [Gender], [Country], [Salary], [Email]) VALUES (40, N'NidhiKhurana', N'F', N'Korea', 5000.0000, N'1NidhiKhurana@gmail.com')
GO
INSERT [dbo].[TblEmployee] ([EmployeeID], [Name], [Gender], [Country], [Salary], [Email]) VALUES (41, N'Ningliu', N'F', N'Korea', 400000.0000, N'1Ningliu@gmail.com')
GO
INSERT [dbo].[TblEmployee] ([EmployeeID], [Name], [Gender], [Country], [Salary], [Email]) VALUES (42, N'PallaviSingh', N'F', N'India', 30000.0000, N'1PallaviSingh@gmail.com')
GO
INSERT [dbo].[TblEmployee] ([EmployeeID], [Name], [Gender], [Country], [Salary], [Email]) VALUES (43, N'SanjayNagaraju', N'M', N'London', 20000.0000, N'1SanjayNagaraju@gmail.com')
GO
INSERT [dbo].[TblEmployee] ([EmployeeID], [Name], [Gender], [Country], [Salary], [Email]) VALUES (44, N'Windylangitan', N'F', N'China', 100000.0000, N'1Windylangitan@gmail.com')
GO
SET IDENTITY_INSERT [dbo].[TblEmployee] OFF
GO
INSERT [dbo].[Users] ([UserId], [Username], [Password], [Email], [Creationdate], [LastLoginDate]) VALUES (1, N'meghana', N'Atcat1234$$', NULL, NULL, NULL)
GO
/****** Object:  StoredProcedure [dbo].[GetBuyerDetails]    Script Date: 3/15/2021 11:49:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create Procedure [dbo].[GetBuyerDetails]
As Begin
(Select Name,Email,Gender,Salary,Country from TblEmployee)
ENd
GO
/****** Object:  StoredProcedure [dbo].[GetInvoiceDetails]    Script Date: 3/15/2021 11:49:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[GetInvoiceDetails]
@InvoiceNumber nvarchar(100),
@InvoiceAmount nvarchar(100),
@PurchagseOrderNumber nvarchar(120),
@InvoiceType nvarchar(10),
@Company nvarchar(40),
@Country nvarchar(30)

As Begin
Truncate Table InvoiceDetailsDump
INsert into InvoiceDetailsDump (InvoiceNUmber,InvoiceAmount,PurchaseOrderNumber,InvoiceType,Company,Country)Values
(@InvoiceNumber,@InvoiceAmount,@PurchagseOrderNumber,@InvoiceType,@Company,@Country)

INsert into InvoiceDetails (InvoiceNUmber,InvoiceAmount,PurchaseOrderNumber,InvoiceType,Company,Country)Values
(@InvoiceNumber,@InvoiceAmount,@PurchagseOrderNumber,@InvoiceType,@Company,@Country)

end
GO
/****** Object:  StoredProcedure [dbo].[Sp_GetEmployeeDetails]    Script Date: 3/15/2021 11:49:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[Sp_GetEmployeeDetails]
@PageIndex int,
@PageSize int,
@TotalRow int output

 As
 Begin
 Declare @StartRowIndex int
 ,@EndRowIndex int

 Set @StartRowIndex=(@PageIndex+@PageSize)+1
 Set @EndRowIndex=	(@PageIndex+1)+@PageSize

 Select EmployeeID, Name,Gender,Country,Salary,Email From (Select ROW_NUMBER()over 
 (order by EmployeeID) as RowNumber,EmployeeID, Name,Gender,Country,Salary,Email from
 TblEmployee )Employee where RowNumber>=7 and RowNumber<=9
 select @TotalRow =count(*) from TblEMployee
 print @TotalRow
 end
GO
/****** Object:  StoredProcedure [dbo].[sp_GetInvoiceDetails]    Script Date: 3/15/2021 11:49:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[sp_GetInvoiceDetails]


As Begin
Truncate Table InvoiceDetailsDump
Select * from InvoiceDetailsDump

end
GO
/****** Object:  StoredProcedure [dbo].[Validate_User]    Script Date: 3/15/2021 11:49:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[Validate_User]
      @Username NVARCHAR(20),
      @Password NVARCHAR(20)
	  
AS
BEGIN

      SET NOCOUNT ON;
      DECLARE @USERID int,  @LastLoginDate DATETIME
     
      SELECT @UserId = UserId, @LastLoginDate = LastLoginDate
      FROM Users WHERE Username = @Username AND [Password] = @Password
     
      IF @UserId IS NOT NULL
      BEGIN
            IF NOT EXISTS(SELECT UserId FROM UserActivation WHERE UserId = @UserId)
            BEGIN
                  UPDATE Users
                  SET LastLoginDate = GETDATE()
                  WHERE UserId = @UserId
                  SELECT @UserId [UserId] -- User Valid
            END
            ELSE
            BEGIN
                  SELECT -2 -- User not activated.
            END
      END
      ELSE
      BEGIN
            SELECT -1 -- User invalid.
      END
END
GO
